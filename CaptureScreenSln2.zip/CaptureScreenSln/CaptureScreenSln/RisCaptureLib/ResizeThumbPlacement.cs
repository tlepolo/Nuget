﻿namespace RisCaptureLib
{
    internal enum ResizeThumbPlacement
    {
        None,
        LeftTop,
        TopCenter,
        RightTop,
        RightCenter,
        RightBottom,
        BottomCenter,
        LeftBottom,
        LeftCenter
    }
}
